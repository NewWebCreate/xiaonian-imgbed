Option Explicit

Dim fso, srcFolder, targetFolder, timeOutSeconds, startTime
Dim sOk, sTimeout, sFail, sTime, sDetected, sExported, sFolder, sNotFound, sErrCode, sErrDesc
Dim fnOk, fnTimeout, fnFail
Dim skipHidden

Set fso = CreateObject("Scripting.FileSystemObject")

srcFolder = "F:\1122334"
targetFolder = "C:\����"
timeOutSeconds = 30
skipHidden = True

sOk = "Ŀ¼�����ɹ���"
sTimeout = "��س�ʱ��"
sFail = "����ʧ�ܣ�"
sTime = "ʱ�䣺"
sDetected = "�Ѽ�⵽ "
sExported = "��ƽ��Ŀ¼�嵥�ѵ����� "
sFolder = "�ļ���"
sNotFound = "����δ��⵽ "
sErrCode = "������룺"
sErrDesc = "������"
fnOk = "Ŀ¼�����ɹ���ʾ.txt"
fnTimeout = "��س�ʱ��ʾ.txt"
fnFail = "Ŀ¼����ʧ����ʾ.txt"

If Not fso.FolderExists(targetFolder) Then
    On Error Resume Next
    fso.CreateFolder targetFolder
    On Error GoTo 0
End If

startTime = Timer()

Do
    If Timer() - startTime >= timeOutSeconds Then
        WriteTip fnTimeout, sTimeout, timeOutSeconds & sNotFound & srcFolder & sFolder
        WScript.Quit
    End If

    If fso.FolderExists(srcFolder) Then
        On Error Resume Next
        Dim outFile
        outFile = targetFolder & "\ƽ��Ŀ¼�嵥.txt"
        Dim ts
        Set ts = fso.CreateTextFile(outFile,True)
        Call ScanFolder(srcFolder, ts, 0, True)
        ts.Close
        If Err.Number = 0 Then
            WriteTip fnOk, sOk, sDetected & srcFolder & sExported & outFile
        Else
            WriteTip fnFail, sFail, sErrCode & Err.Number & vbCrLf & sErrDesc & Err.Description
        End If
        On Error GoTo 0
        WScript.Quit
    End If

    WScript.Sleep 500
Loop

Sub ScanFolder(path, ts, level, isRoot)
    Dim fd, f, subFd, indent
    Set fd = fso.GetFolder(path)
    
    If LCase(fd.Name) = "system volume information" Or LCase(fd.Name) = "$recycle.bin" Then Exit Sub
    
    If Not isRoot Then
        If skipHidden And (fd.Attributes And 2) Then Exit Sub
    End If
    
    indent = String(level, "    ")
    ts.WriteLine indent & "[�ļ���] " & fd.Path
    
    For Each f In fd.Files
        If Not (skipHidden And (f.Attributes And 2)) Then
            ts.WriteLine indent & "    [�ļ�]   " & f.Path
        End If
    Next
    
    For Each subFd In fd.SubFolders
        On Error Resume Next
        ScanFolder subFd.Path, ts, level + 1, False
        On Error GoTo 0
    Next
End Sub

Sub WriteTip(fileName, headLine, detailLine)
    Dim f, txtPath
    On Error Resume Next
    txtPath = targetFolder & "\" & fileName
    Set f = fso.CreateTextFile(txtPath, True)
    f.WriteLine headLine
    f.WriteLine sTime & Now
    f.WriteLine ""
    f.WriteLine detailLine
    f.Close
    On Error GoTo 0
End Sub
